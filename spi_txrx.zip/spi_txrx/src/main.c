#include <stdio.h>
#include "tremo_regs.h"
#include "tremo_rcc.h"
#include "tremo_spi.h"
#include "tremo_gpio.h"
#include "tremo_uart.h"

void uart_log_init(void)
{
    // uart0
    gpio_set_iomux(GPIOB, GPIO_PIN_0, 1);
    gpio_set_iomux(GPIOB, GPIO_PIN_1, 1);

    /* uart config struct init */
    uart_config_t uart_config;
    uart_config_init(&uart_config);

    uart_config.baudrate = UART_BAUDRATE_115200;
    uart_init(CONFIG_DEBUG_UART, &uart_config);
    uart_cmd(CONFIG_DEBUG_UART, ENABLE);
}

void spi1_tx_rx(void)
{
    ssp_init_t spi_config;

    rcc_enable_peripheral_clk(RCC_PERIPHERAL_SSP1, true);
    rcc_enable_peripheral_clk(RCC_PERIPHERAL_GPIOA, true);

    gpio_set_iomux(GPIOA, GPIO_PIN_4, 4); // CLK
    gpio_set_iomux(GPIOA, GPIO_PIN_5, 4); // NSS
    gpio_set_iomux(GPIOA, GPIO_PIN_6, 4); // MOSI
    gpio_set_iomux(GPIOA, GPIO_PIN_7, 4); // MISO

    gpio_init(GPIOA, GPIO_PIN_5, GPIO_MODE_OUTPUT_PP_HIGH); // NSS as GPIO output

    ssp_init_struct(&spi_config);
    ssp_init(SSP1, &spi_config);
    ssp_cmd(SSP1, ENABLE);
}

uint8_t spi_transfer(uint8_t tx_byte)
{
    // Đợi TX FIFO trống
    while (!(ssp_get_flag_status(SSP1, SSP_FLAG_TX_FIFO_NOT_FULL)));
    SSP1->DR = tx_byte;

    // Đợi RX FIFO có dữ liệu
    while (!(ssp_get_flag_status(SSP1, SSP_FLAG_RX_FIFO_NOT_EMPTY)));
    return (uint8_t)(SSP1->DR);
}

uint8_t sx1276_read_register(uint8_t addr)
{
    uint8_t response;

    // Bit 7 = 0 (read), giữ nguyên addr
    addr &= 0x7F;

    // Kéo NSS xuống LOW
    gpio_write(GPIOA, GPIO_PIN_5, 0);

    spi_transfer(addr);           // gửi địa chỉ
    response = spi_transfer(0x00); // nhận dữ liệu

    // Kéo NSS lên HIGH
    gpio_write(GPIOA, GPIO_PIN_5, 1);

    return response;
}

int main(void)
{
    rcc_enable_peripheral_clk(RCC_PERIPHERAL_GPIOB, true);
    rcc_enable_peripheral_clk(RCC_PERIPHERAL_UART0, true);

    uart_log_init();

    spi1_tx_rx();

    uint8_t version = sx1276_read_register(0x42);
    printf("SX1276 Version (Reg 0x42): 0x%02X\r\n", version);

    while (1) {}
}

#ifdef USE_FULL_ASSERT
void assert_failed(void* file, uint32_t line)
{
    (void)file;
    (void)line;

    while (1) { }
}
#endif
